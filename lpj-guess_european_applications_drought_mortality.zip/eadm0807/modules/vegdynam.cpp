///////////////////////////////////////////////////////////////////////////////////////
/// \file vegdynam.cpp
/// \brief Vegetation dynamics and disturbance
///
/// \author Ben Smith
/// $Date: 2023-02-13 11:34:52 +0100 (Mon, 13 Feb 2023) $
///
///////////////////////////////////////////////////////////////////////////////////////

// WHAT SHOULD THIS FILE CONTAIN?
// Module source code files should contain, in this order:
//   (1) a "#include" directive naming the framework header file. The framework header
//       file should define all classes used as arguments to functions in the present
//       module. It may also include declarations of global functions, constants and
//       types, accessible throughout the model code;
//   (2) other #includes, including header files for other modules accessed by the
//       present one;
//   (3) type definitions, constants and file scope global variables for use within
//       the present module only;
//   (4) declarations of functions defined in this file, if needed;
//   (5) definitions of all functions. Functions that are to be accessible to other
//       modules or to the calling framework should be declared in the module header
//       file.
//
// PORTING MODULES BETWEEN FRAMEWORKS:
// Modules should be structured so as to be fully portable between models (frameworks).
// When porting between frameworks, the only change required should normally be in the
// "#include" directive referring to the framework header file.

#include "config.h"
#include "vegdynam.h"
#include "growth.h"
#include "driver.h"

// Alternatives for forestry:

/// Whether to use smaller sapsize in managed forests after cutting (defined by PLANTSIZE) when not using planting()
const bool SMALL_SAPSIZE_POST_CUT = false;

/// Fixed initial individual plantsize (kgC) in tree planting after clearcut if SMALL_SAPSIZE_POST_CUT == true
const double PLANTSIZE = 0.25;

/// Upper LAI limit for wetland species. No limit: 0 //TODO remove this after daily allocation.
const double wetlandlailimit = 2.0;

/// Internal help function for splitting up nitrogen fire fluxes into components
void report_fire_nfluxes(Patch& patch, double nflux_fire) {
	patch.fluxes.report_flux(Fluxes::NH3_FIRE, Fluxes::NH3_FIRERATIO * nflux_fire);
	patch.fluxes.report_flux(Fluxes::NOx_FIRE, Fluxes::NOx_FIRERATIO * nflux_fire);
	patch.fluxes.report_flux(Fluxes::N2O_FIRE, Fluxes::N2O_FIRERATIO * nflux_fire);
	patch.fluxes.report_flux(Fluxes::N2_FIRE,  Fluxes::N2_FIRERATIO  * nflux_fire);
}


///////////////////////////////////////////////////////////////////////////////////////
// RANDPOISSON
// Internal functions for generating random numbers

int randpoisson(double expectation, long& seed) {

	// DESCRIPTION
	// Returns a random integer drawn from the Poisson distribution with specified
	// expectation (for computational reasons, the Gaussian normal distribution is
	// used as an approximation of the Poisson distribution for expected values >100)

	double p, q, r;
	int n;

	if (expectation <= 100) {

		// For expected values up to 100, calculate a true Poisson number

		p = exp(-expectation);
		q = p;
		r=randfrac(seed);

		n = 0;
		while (q < r) {
			n++;
			p *= expectation / (double)n;
			q += p;
		}
		return n;
	}

	// For higher expected values than 100, approximate the Poisson distribution
	// by the Gaussian normal distribution with mean equal to the expected value,
	// and standard deviation the square root of this value

	do {
		r=randfrac(seed)*8.0-4.0;
		p = exp(-r * r / 2.0);
	} while (randfrac(seed)>p);

	return max(0, (int)(r * sqrt(expectation) + expectation + 0.5));
}


///////////////////////////////////////////////////////////////////////////////////////
// BIOCLIMATIC LIMITS ON ESTABLISHMENT AND SURVIVAL
// Internal functions (do not call directly from framework)

bool establish(Patch& patch, const Climate& climate, Pft& pft) {

	// DESCRIPTION
	// Determines whether specified PFT is within its bioclimatic limits for
	// establishment in a given patch and climate. Returns true if PFT can establish
	// under specified conditions, false otherwise

	// The following limits are implemented:
	//   tcmin_est   = minimum coldest month mean temperature for the last 20 years
	//   tcmax_est   = maximum coldest month mean temperature for the last 20 years
	//   twmin_est   = minimum warmest month mean temperature
	//   gdd5min_est = minimum growing degree day sum on 5 deg C base
	// Special rules for forestry after clearcut
	ManagementType& mt = patch.stand.get_current_management();
	Standpft& spft = patch.stand.pft[pft.id];
	bool pft_selection = spft.plant;

	// Bypass temperature limits of establishment for selected species
	bool relaxed_establishment = patch.plant_this_year && mt.relaxed_establishment && pft_selection;

	if (!relaxed_establishment && (climate.mtemp_min20 < pft.tcmin_est ||
		climate.mtemp_min20 > pft.tcmax_est ||
		climate.mtemp_max < pft.twmin_est ||
		climate.agdd5 < pft.gdd5min_est)) return false;

	if (!relaxed_establishment && !iftwolayersoil) {
		// Wolf et al. (2008) bioclimatic limits related to snow depth and GDD0
		if ((climate.lat >= 0.0 && ((patch.soil.msnowdepth[0] + patch.soil.msnowdepth[1] + patch.soil.dec_snowdepth) / 3.0) < pft.min_snow) ||
			(climate.lat < 0.0 && ((patch.soil.msnowdepth[5] + patch.soil.msnowdepth[6] + patch.soil.msnowdepth[7]) / 3.0) < pft.min_snow) ||
			climate.agdd0_20.mean() <= pft.gdd0_min || climate.agdd0_20.mean() >= pft.gdd0_max) return false;
	}

	/* Bypass all environmental limits except temperature for selected tree species after clearcut
	 * (par_grass_mean not updated yet)
	 */
	if(patch.plant_this_year && (pft_selection || mt.planting_system == ""))
		return true;

	if(patch.stand.landcover != CROPLAND) {
		if (vegmode != POPULATION && patch.par_grass_mean < pft.parff_min) return false;
	}

	// guess2008 - drought limited establishment
    if (ifdroughtlimitedestab && patch.stand.landcover != PEATLAND) {
		// Compare this PFT's/species' drought_tolerance with the average wcont over the
		// growing season, in this patch. Higher drought_tolerance values (set in the .ins file)
		// lead to greater restrictions on establishment.
        if (pft.drought_tolerance > patch.soil.awcont_upper) {
           return false;
        }
    }
	// else

	return true;
}


bool survive(const Climate& climate, Pft& pft) {

	// DESCRIPTION
	// Determines whether specified PFT is within its bioclimatic limits for survival
	// in a given climate. Returns true if PFT can survive in the specified climate,
	// false otherwise

	// The following limit is implemented:
	//   tcmin_surv = minimum coldest month temperature for the last 20 years (deg C)

	if (climate.mtemp_min20 < pft.tcmin_surv ||
		climate.mtemp_max20 - climate.mtemp_min20 < pft.twminusc) return false;

	// else

	return true;
}


///////////////////////////////////////////////////////////////////////////////////////
// ESTABLISHMENT
// Internal functions (do not call directly from framework)

void establishment_lpj(Stand& stand,Patch& patch) {

	// DESCRIPTION
	// Establishment in population (standard LPJ) mode.
	// Simulates population increase through establishment each simulation year for
	// trees and grasses and introduces new PFTs if climate conditions become suitable.
	// This function assumes each Individual object represents the average individual
	// of a PFT population, and that there is (at most) one Individual object per PFT
	// per modelled area (stand and patch).
	// This is the only function in which new average individuals are added to the
	// vegetation in population mode.

	const double K_EST=0.12; // maximum overall sapling establishment rate (indiv/m2)

	double fpc_tree;  // summed fractional cover for tree PFTs
	double fpc_grass; // summed fractional cover for grass PFTs
	double est_tree;  // overall establishment rate for trees on modelled area basis (indiv/m2)

	// Establishment rate for a particular PFT on modelled area basis (for trees,
	// indiv/m2; for grasses, fraction of modelled area colonised)
	double est_pft;

	int ntree_est;	  // number of establishing tree PFTs
	int ngrass_est;	  // number of establishing grass PFTs
	bool present;

	// Obtain reference to Vegetation object

	Vegetation& vegetation=patch.vegetation;

	// Loop through all possible PFTs to determine whether there are any not currently
	// present but within their bioclimatic limits for establishment

	pftlist.firstobj();
	while (pftlist.isobj) {
		Pft& pft=pftlist.getobj();

		if (stand.pft[pft.id].active) {	// standpft.active is set in landcover_init according to rules for each stand

		// Is this PFT already represented?

			present=false;
			vegetation.firstobj();
			while (vegetation.isobj && !present) {
				Individual& indiv=vegetation.getobj();
				if (indiv.pft.id==pft.id) present=true;
				vegetation.nextobj();
			}

			if (!present) {
				if (establish(patch,stand.get_climate(),pft)) {

					// Not present but can establish, so introduce as new average
					// individual

					Individual& indiv=vegetation.createobj(pft,vegetation);
					if (pft.lifeform == GRASS || pft.lifeform == MOSS) {
						indiv.height=0.0;
						indiv.crownarea=1.0; // (value not used)
						indiv.densindiv=1.0;
						indiv.fpc=0.0;
					}
				}
			}
		}
		pftlist.nextobj(); // ... on to next PFT
	}

	// Calculate total FPC and number of PFT's (i.e. average individuals) establishing
	// this year for trees and grasses respectively

	fpc_tree=0.0;
	fpc_grass=0.0;
	ntree_est=0;
	ngrass_est=0;

	// Loop through individuals

	vegetation.firstobj();
	while (vegetation.isobj) {
		Individual& indiv=vegetation.getobj();

		// For this individual ...

		if (indiv.pft.lifeform==TREE) {
			if (establish(patch, stand.get_climate(), indiv.pft)) ntree_est++;
			fpc_tree+=indiv.fpc;
		}
		else if (indiv.pft.lifeform == GRASS || indiv.pft.lifeform == MOSS) {
			fpc_grass+=indiv.fpc;
			if (establish(patch, stand.get_climate(), indiv.pft)) ngrass_est++;
		}

		vegetation.nextobj(); // ... on to next individual
	}

	// Calculate overall establishment rate for trees
	// Trees can establish in unoccupied regions of the stand, and in regions
	// occupied by grasses. Establishment reduced in response to canopy closure as
	// tree cover approaches 100%
	// Smith et al 2001, Eqn (17)

	est_tree=K_EST*(1.0-exp(-5.0*(1.0-fpc_tree)))*(1.0-fpc_tree);

	// Loop through individuals

	vegetation.firstobj();
	while (vegetation.isobj) {

		// For this individual ...

		Individual& indiv=vegetation.getobj();

		if (indiv.pft.lifeform==TREE && establish(patch, stand.get_climate(), indiv.pft)) {

			// ESTABLISHMENT OF NEW TREE SAPLINGS
			// Partition overall establishment equally among establishing PFTs

			est_pft=est_tree/(double)ntree_est;

			if (est_pft<0.0)
				fail("establishment_area: negative establishment rate");

			// Adjust density of individuals across modelled area to account for
			// addition of new saplings

			indiv.densindiv+=est_pft;

			// Account for flux from the atmosphere to new saplings
			// (flux is downward and therefore negative)
			if(!indiv.istruecrop_or_intercropgrass()) {
				indiv.report_flux(Fluxes::ESTC,
								  -(indiv.pft.regen.cmass_leaf+
									indiv.pft.regen.cmass_root+indiv.pft.regen.cmass_sap+
									indiv.pft.regen.cmass_heart)*est_pft);
			}

			// Adjust average individual C biomass based on average biomass and density
			// of the new saplings

			indiv.cmass_leaf+=indiv.pft.regen.cmass_leaf*est_pft;
			indiv.cmass_root+=indiv.pft.regen.cmass_root*est_pft;
			indiv.cmass_sap+=indiv.pft.regen.cmass_sap*est_pft;
			indiv.cmass_heart+=indiv.pft.regen.cmass_heart*est_pft;

			// Calculate storage pool size
			indiv.max_n_storage = (indiv.cmass_leaf + indiv.cmass_root) / indiv.pft.cton_leaf_avr;
			if (!indiv.alive)
				indiv.scale_n_storage = indiv.max_n_storage * indiv.pft.cton_leaf_avr /
					((indiv.pft.regen.cmass_leaf + indiv.pft.regen.cmass_root +
					indiv.pft.regen.cmass_sap +	indiv.pft.regen.cmass_heart) * est_pft);
		}
		else if (((indiv.pft.lifeform==GRASS || indiv.pft.lifeform==MOSS) && indiv.pft.phenology!=CROPGREEN) &&
			establish(patch, stand.get_climate(), indiv.pft)) {

			// ESTABLISHMENT OF GRASSES AND MOSSES
			// Grasses establish throughout unoccupied regions of the grid cell
			// Overall establishment partitioned equally among establishing PFTs

			est_pft=(1.0-fpc_tree-fpc_grass)/(double)ngrass_est;

			// Account for flux from atmosphere to grass regeneration
			if (!indiv.istruecrop_or_intercropgrass()) {
				indiv.report_flux(Fluxes::ESTC,
			                  -(indiv.pft.regen.cmass_leaf+
			                    indiv.pft.regen.cmass_root)*est_pft);
			}

			// Add regeneration biomass to overall biomass

			indiv.cmass_leaf+=est_pft*indiv.pft.regen.cmass_leaf;
			indiv.cmass_root+=est_pft*indiv.pft.regen.cmass_root;

			// Calculate storage pool size
			indiv.max_n_storage = (indiv.cmass_leaf + indiv.cmass_root) / indiv.pft.cton_leaf_avr;
			if (!indiv.alive)
				indiv.scale_n_storage = indiv.max_n_storage * indiv.pft.cton_leaf_avr /
					((indiv.pft.regen.cmass_leaf + indiv.pft.regen.cmass_root) * est_pft);
		}

		// Update allometry to account for changes in average individual biomass

		allometry(indiv);

		vegetation.nextobj(); // ... on to next individual
	}
}


void establishment_guess(Stand& stand,Patch& patch) {

	// DESCRIPTION
	// Establishment in cohort or individual mode.
	// Establishes new tree saplings and simulates grass population increase each
	// establishment year (every year in individual mode). New grass PFTs are
	// introduced (any year) if climate conditions become suitable.
	// Saplings are given an amount of carbon proportional to the hypothetical forest
	// floor NPP for this year and are "moulded" by calls to the standard allocation
	// function (growth module). The coefficient SAPSIZE controls the relative amount
	// of carbon given each sapling and should be set to a value resulting in saplings
	// around breast height in the first year (before development of a shading canopy).

	// For tree PFTs within their bioclimatic limits for establishment, the expected
	// number of saplings (est) established in each patch is given by:
	//
	// for model initialisation:
	//   (1) est = est_max*patcharea
	// if spatial mass effect enabled (stand-level "propagule pool" influences
	// establishment):
	//   (2) est = c*(kest_repr*cmass_repr+kest_bg)
	// if no spatial mass effect and propagule pool exists (cmass_repr non-negligible):
	//   (3) est = c*(kest_pres+kest_bg)
	// if no spatial mass effect and no propagule pool:
	//   (4) est = c*kest_bg
	// where
	//   (5) c = mu(anetps_ff/anetps_ff_max)*est_max*patcharea
	//   (6) mu(F) = exp(alphar*(1-1/F)) (Fulton 1991, Eqn 4)
	// where
	//   kest_repr     = PFT-specific constant (kest_repr*cmass_repr should
	//                   approximately equal 1 at the highest plausible value of
	//                   cmass_repr for the PFT)
	//   kest_bg       = PFT-specific constant in range 0-1 (usually << 1)
	//                   (set to zero if background establishment disabled)
	//   kest_pres     = PFT-specific constant in range 0-1 (usually ~1)
	//   cmass_repr    = net C allocated to reproduction for this PFT in all patches of
	//                   this stand this year (kgC/m2)
	//   est_max       = (nominal) maximum establishment rate for this PFT
	//                  (saplings/m2/year)
	//   patcharea     = patch area (m2)
	//   anetps_ff     = potential annual net assimilation at forest floor for this
	//                   PFT (kgC/m2/year)
	//   anetps_ff_max = maximum value of anetps_ff for this PFT in this stand so far
	//                   in the simulation (kgC/m2/year)
	//   alphar        = PFT-specific constant (parameter capturing non-linearity in
	//                   recruitment rate relative to understorey growing conditions)
	//
	// In individual mode, and in cohort mode if stochastic establishment is enabled,
	// the actual number of new saplings established is a number drawn from the Poisson
	// distribution with expectation 'est'. In cohort mode, with stochastic
	// establishment disabled, a cohort representing exactly 'est' individuals (may be
	// not-integral) is established.

	// Coefficient in calculation of initial sapling size and initial
	// grass biomass (see comment above)
	const double SAPSIZE=0.1;

	bool present = false; // whether PFT already present in this patch
	double c = 0.0; // constant in equation for number of new saplings (Eqn 5)
	double est = 0.0; // expected number of new saplings for PFT in this patch

	// Actual number of new saplings for PFT in this patch (may include a
	// fractional part in cohort mode with stochastic establishment disabled)
	double nsapling = 0.0;
	double bminit = 0.0; // initial sapling biomass (kgC) or new grass biomass (kgC/m2)
	double ltor = 0.0; // leaf to fine root mass ratio for new saplings or grass
	int newindiv = 0; // number of new Individual objects to add to vegetation for this PFT
	double kest_bg = 0.0;
	int i = 0;

	// Obtain reference to Vegetation object

	Vegetation& vegetation=patch.vegetation;

	const bool establish_active_pfts_before_management = true;
	const bool cloned_or_changed_man = stand.cloned || stand.current_rot;

	ManagementType& mt = patch.stand.get_current_management();
	if(patch.plant_this_year && mt.set_planting_density && mt.planting_system != "") {
		planting(patch);	// NB planting() gives small fixed sapsize
		return;
	}

	// guess2008 - determine the number of woody PFTs that can establish
	// Thomas Hickler
	int nwoodypfts_estab=0;
	pftlist.firstobj();
	while (pftlist.isobj) {
		Pft& pft=pftlist.getobj();
		Standpft& standpft=stand.pft[pft.id];

		// Force planting if planting() not used
		bool force_planting = 
			patch.plant_this_year && standpft.plant && !(mt.set_planting_density && mt.planting_system != "");
		bool est_this_year;
		if(establish_active_pfts_before_management) {
			est_this_year = !patch.managed && !cloned_or_changed_man || !patch.plant_this_year && standpft.reestab;
		}
		else {
			est_this_year = !run_landcover || !patch.plant_this_year && standpft.reestab;
		}

		if (establish(patch, stand.get_climate(), pft) && pft.lifeform == TREE && standpft.active 
				&& (est_this_year || force_planting)) {
			nwoodypfts_estab++;
		}
		pftlist.nextobj();
	}


	// Loop through PFTs
	
	pftlist.firstobj();
	while (pftlist.isobj) {
		Pft& pft=pftlist.getobj();
		Standpft& standpft=stand.pft[pft.id];

		// For this PFT ...

		// Stands cloned this year to be treated here as first year
		bool init_clone = date.year == stand.clone_year && pft.landcover == stand.landcover;

		// Force planting of pfts in selection in managed forest stands after clear-cut if planting() not used
		// No grass establishment will occur during planting year (force_planting is always false for grass and 
		// est_this_year is false when patch.plant_this_year is true)
		bool force_planting = 
			patch.plant_this_year && standpft.plant && !(mt.set_planting_density && mt.planting_system != "");
		bool est_this_year;
		if(establish_active_pfts_before_management) {
			est_this_year = !patch.managed && !cloned_or_changed_man || !patch.plant_this_year && standpft.reestab;
		}
		else {
			est_this_year = !run_landcover || !patch.plant_this_year && standpft.reestab;
		}

		if (stand.pft[pft.id].active) {
			if (patch.age==0 || init_clone) {
				patch.pft[pft.id].anetps_ff_est=patch.pft[pft.id].anetps_ff;
				patch.pft[pft.id].wscal_mean_est=patch.pft[pft.id].wscal_mean;

				// BLARP
				if (date.year==0 || date.year==stand.first_year || init_clone || force_planting) // also after clearcut
					patch.pft[pft.id].anetps_ff_est_initial=patch.pft[pft.id].anetps_ff;

			}
			else {
				patch.pft[pft.id].anetps_ff_est+=patch.pft[pft.id].anetps_ff;
				patch.pft[pft.id].wscal_mean_est+=patch.pft[pft.id].wscal_mean;
			}

			if (establish(patch, stand.get_climate(), pft) && (est_this_year || force_planting)) {

				if (pft.lifeform==GRASS || pft.lifeform==MOSS) {

					// ESTABLISHMENT OF GRASSES AND MOSSES

					// Each grass PFT represented by just one individual in each patch
					// Check whether this grass PFT already represented ...

					present=false;
					vegetation.firstobj();
					while (vegetation.isobj && !present) {
						if (vegetation.getobj().pft.id==pft.id) present=true;
						vegetation.nextobj();
					}

					if (!present) {

						// ... if not, add it

						Individual& indiv=vegetation.createobj(pft,vegetation);
						indiv.height=0.0;
						indiv.crownarea=1.0; // (value not used)
						indiv.densindiv=1.0;
						indiv.fpc=1.0;

						// Initial grass biomass proportional to potential forest floor
						// net assimilation this year on patch area basis

						if(pft.phenology == CROPGREEN) {
							bminit = SAPSIZE * 0.01;
						}
						else if(patch.has_disturbances() && patch.disturbed) {
							bminit = SAPSIZE * patch.pft[pft.id].anetps_ff_est_initial;
						}
						else {
							bminit = SAPSIZE * patch.pft[pft.id].anetps_ff;
						}

						// Initial leaf to fine root biomass ratio based on
						// hypothetical value of water stress parameter

						ltor=patch.pft[pft.id].wscal_mean*pft.ltor_max;

						// Allocate initial biomass
						if(!indiv.istruecrop_or_intercropgrass())
							allocation_init(bminit,ltor,indiv);

						// Calculate initial allometry

						allometry(indiv);

						// Calculate storage pool size
						if(indiv.pft.phenology == CROPGREEN) {
							indiv.max_n_storage = CMASS_SEED / indiv.pft.cton_leaf_avr;
							indiv.scale_n_storage = indiv.max_n_storage * indiv.pft.cton_leaf_avr / CMASS_SEED;
						}
						else {
							indiv.max_n_storage = indiv.cmass_root * indiv.pft.fnstorage / indiv.pft.cton_leaf_avr;
							indiv.scale_n_storage = indiv.max_n_storage * indiv.pft.cton_leaf_avr / bminit;
						}

						// Establishment flux is not debited for 'new' Individual
						// objects - their carbon is debited in function growth()
						// if they survive the first year
					}
				}
				else if (pft.lifeform==TREE) {

					// ESTABLISHMENT OF NEW TREE SAPLINGS

					if (patch.age == 0 || init_clone){

						// First simulation year - initialising patch
						// Eqn 1

						est=pft.est_max*patcharea;
					}
					else {

						// Every year except year 1
						// Eqns 5, 6

						if (patch.pft[pft.id].anetps_ff>0.0 &&
							!negligible(patch.pft[pft.id].anetps_ff)) {

							c=exp(pft.alphar-pft.alphar/patch.pft[pft.id].anetps_ff*
								stand.pft[pft.id].anetps_ff_max)*pft.est_max*patcharea;
						}
						else {
							c=0.0;
						}

						// Background establishment enabled?

						if (ifbgestab)
							kest_bg=pft.kest_bg;
						else
							kest_bg=0.0;

						// Spatial mass effect enabled?
						// Eqns 2, 3, 4

						if (ifsme)
							est=c*(pft.kest_repr*stand.pft[pft.id].cmass_repr+kest_bg);
						else if (!negligible(stand.pft[pft.id].cmass_repr))
							est=c*(pft.kest_pres+kest_bg);
						else
							est=c*kest_bg;
					}


					// guess2008 - scale est by the number of woody PFTs/species that can establish
					// Otherwise, simply adding more PFTs or species would increase est
					est*=min(1.0,3.0/double(nwoodypfts_estab));
					//est*=3.0/double(nwoodypfts_estab);


					// Have a value for expected number of new saplings (est)
					// Actual number of new saplings drawn from the Poisson distribution
					// (except cohort mode with stochastic establishment disabled)

					if (ifstochestab && mt.stochestab && !force_planting || vegmode==INDIVIDUAL) {
						nsapling=randpoisson(est, stand.seed);
					}
					else { 
						nsapling=est;
					}

					if (vegmode==COHORT) {

						// BLARP added for OECD experiment (is this sensible?)
						if (patch.has_disturbances() && patch.disturbed || force_planting) {

							patch.pft[pft.id].anetps_ff_est=
								patch.pft[pft.id].anetps_ff_est_initial;
							patch.pft[pft.id].wscal_mean_est=patch.pft[pft.id].wscal_mean;
							newindiv=!negligible(nsapling / patcharea);
						}
						else if (patch.age%estinterval && !init_clone || patch.plant_this_year) {

							// Not an establishment year - save sapling count for
							// establishment the next establishment year
							// Establishment each year in managed patches

							patch.pft[pft.id].nsapling+=nsapling;
							newindiv=0;
						}
						else {
							if (patch.age && !init_clone) {// all except first year after disturbance
								nsapling+=patch.pft[pft.id].nsapling;
								patch.pft[pft.id].anetps_ff_est/=(double)estinterval;
								patch.pft[pft.id].wscal_mean_est/=(double)estinterval;
							}
							newindiv=!negligible(nsapling / patcharea);
								// round down to 0 if nsapling very small
						}
					}
					else if (vegmode == INDIVIDUAL) {
						newindiv=(int)(nsapling+0.5); // round up to be on the safe side
					}

					// Now create 'newindiv' new Individual objects

					for (i=0;i<newindiv;i++) {

						// Create average individual for a new cohort (cohort mode)
						// or an actual individual (individual mode)

						Individual& indiv=vegetation.createobj(pft,vegetation);

						if (vegmode==COHORT)
							indiv.densindiv=nsapling/patcharea;
						else if (vegmode==INDIVIDUAL)
							indiv.densindiv=1.0/patcharea;

						indiv.age=0.0;

						// Initial biomass proportional to potential forest floor net
						// assimilation for this PFT in this patch

						if (patch.has_been_cut && (SMALL_SAPSIZE_POST_CUT && force_planting && mt.planting_system != "")) {
							bminit = PLANTSIZE; // Fixed sap size after first cutting
						}
						else {
							bminit = SAPSIZE*patch.pft[pft.id].anetps_ff_est;
						}

						// Initial leaf to fine root biomass ratio based on hypothetical
						// value of water stress parameter

						ltor=patch.pft[pft.id].wscal_mean_est*pft.ltor_max;

						// Allocate initial biomass
						if (ifnewalloc) {
							bminit = 1.0 / indiv.pft.sla;
							allocation_init(bminit,ltor,indiv,0.0);
						} else {
							allocation_init(bminit,ltor,indiv);
						}
						

						// Calculate initial allometry

						allometry(indiv);

						// Calculate storage pool size
						indiv.max_n_storage = indiv.cmass_sap * indiv.pft.fnstorage / indiv.pft.cton_leaf_avr;
						indiv.scale_n_storage = indiv.max_n_storage * indiv.pft.cton_leaf_avr / bminit;

						// Establishment flux is not debited for 'new' Individual
						// objects - their carbon is debited in function growth()
						// if they survive the first year
					}
				}
			}

			// Reset running sums for next year (establishment years only in cohort mode)

			if (vegmode!=COHORT || !(patch.age%estinterval)) {
				patch.pft[pft.id].nsapling=0.0;
				patch.pft[pft.id].wscal_mean_est=0.0;
				patch.pft[pft.id].anetps_ff_est=0.0;
			}

		}

		// ... on to next PFT
		pftlist.nextobj();
	}
}


///////////////////////////////////////////////////////////////////////////////////////
// MORTALITY
// Internal functions (do not call directly from framework)

void mortality_lpj(Stand& stand, Patch& patch, const Climate& climate, double fireprob) {

	// DESCRIPTION
	// Mortality in population (standard LPJ) mode.
	// Simulates population decrease through mortality each simulation year for trees
	// and grasses; "kills" PFT populations if climate conditions become unsuitable for
	// survival.
	// This function assumes each Individual object represents the average individual
	// of a PFT population, and that there is (at most) one Individual object per PFT
	// per modelled area (stand and patch).

	// For tree PFTs, the fraction of the population killed is given by:
	//
	//   (1) mort = min ( mort_greff + mort_shade + mort_fire, 1)
	// where mort_greff = mortality preempted by low growth efficiency, given by:
	//   (2) mort_greff = K_MORT1 / (1 + K_MORT2*greff)
	//   (3) greff = annual_npp / leaf_area
	//   (4) leaf_area = cmass_leaf * sla
	// mort_shade = mortality due to shading ("self thinning") as total tree cover
	//   approaches 1 (see code)
	// mort_fire = mortality due to fire when using fire model GLOBFIRM. 
	//   Fire model BLAZE handles fire mortality separately. See blaze.cpp.
	//   the fraction of the modelled area affected by
	//   fire (fireprob) is calculated in function fire; actual mortality is influenced
	//   by PFT-specific resistance to burning (see code).
	//
	// Grasses are subject to shading and fire mortality only

	// References: Sitch et al 2001, Smith et al 2001, Thonicke et al 2001

	// INPUT PARAMETER
	// fireprob = fraction of modelled area affected by fire

	// Constant in mortality equation [c.f. mort_max; LPJF]
	const double K_MORT1=0.01; 
	// Constant in mortality equation [c.f. k_mort; LPJF]; the value here differs
	// from LPJF's k_mort in that growth efficiency here based on annual NPP, c.f.
	// net growth increment; LPJF	
	const double K_MORT2=35.0;
	const double FPC_TREE_MAX=0.95; // maximum summed tree fractional projective cover

	double fpc_dec; // required reduction in FPC
	double fpc_tree; // summed FPC for all tree PFTs
	double fpc_grass; // summed FPC for all grasses
	double deltafpc_tree_total; // total tree increase in FPC this year
	
	// Total mortality for PFT (fraction of current FPC)
	double mort;
	// Background mortality plus mortality preempted by low growth efficiency
	// (fraction of current FPC)
	double mort_greffic;
	// Mortality associated with light competition (fraction of current FPC)
	double mort_shade;
	double mort_fire;
	bool killed;

	// Obtain reference Vegetation object

	Vegetation& vegetation=patch.vegetation;

	// Calculate total tree and grass FPC and total increase in FPC this year for trees

	fpc_tree=0.0;
	fpc_grass=0.0;
	deltafpc_tree_total=0.0;

	// Loop through individuals

	vegetation.firstobj();
	while (vegetation.isobj) {
		Individual& indiv=vegetation.getobj();

		// For this individual ...

		if (indiv.pft.lifeform==TREE) {

			fpc_tree+=indiv.fpc;
			if (indiv.deltafpc<0.0) indiv.deltafpc=0.0;
			deltafpc_tree_total+=indiv.deltafpc;

		}
		else if (indiv.pft.lifeform==GRASS || indiv.pft.lifeform == MOSS) fpc_grass+=indiv.fpc;

		vegetation.nextobj(); // ... on to next individual
	}

	// KILL PFTs BEYOND BIOCLIMATIC LIMITS FOR SURVIVAL

	// Loop through individuals

	vegetation.firstobj();
	while (vegetation.isobj) {
		Individual& indiv=vegetation.getobj();

		// For this individual ...

		killed=false;

		if (!survive(climate,indiv.pft)) {

			// Remove completely if PFT beyond its bioclimatic limits for survival

			indiv.kill();

			vegetation.killobj();
			killed=true;
		}

		if (!killed) vegetation.nextobj(); // ... on to next individual
	}

	// CALCULATE AND IMPLEMENT MORTALITY

	// Loop through individuals

	vegetation.firstobj();
	while (vegetation.isobj) {
		Individual& indiv=vegetation.getobj();

		// For this individual ...

		killed=false;

		if (indiv.pft.lifeform==TREE) {

			// TREE MORTALITY

			// Mortality associated with low growth efficiency (includes
			// parameterisation of population background mortality)
			// NOTE: growth efficiency quantified as (annual NPP)/(leaf area)
			//       c.f. LPJF, which uses net growth increment instead of NPP

			mort_greffic=K_MORT1/(1.0+K_MORT2*max(indiv.anpp,0.0)/indiv.cmass_leaf/
				indiv.pft.sla);

			// Mortality associated with light competition
			// Self thinning imposed when total tree cover above FPC_TREE_MAX,
			// partitioned among tree PFTs in proportion to this year's FPC increment

			if (fpc_tree>FPC_TREE_MAX) {
				if (!negligible(deltafpc_tree_total))
					fpc_dec=(fpc_tree-FPC_TREE_MAX)*indiv.deltafpc/deltafpc_tree_total;
				else
					fpc_dec=0.0;
				mort_shade=1.0-fracmass_lpj(indiv.fpc-fpc_dec,indiv.fpc,indiv);
			}
			else
				mort_shade=0.0;

			// Mortality due to fire when using fire model GLOBFIRM (BLAZE handles it separately)
			if (patch.has_fires() && firemodel == GLOBFIRM) {
				mort_fire=fireprob*(1.0-indiv.pft.fireresist);
			}
			else { 
				mort_fire=0.0; 
			}

			// Sum mortality components to give total mortality (maximum 1)

			mort=min(mort_greffic+mort_shade+mort_fire,1.0);

			// Reduce population density and C biomass on modelled area basis
			// to account for loss of killed individuals
			indiv.reduce_biomass(mort, mort_fire);
		}
		else if (indiv.pft.lifeform==GRASS || indiv.pft.lifeform == MOSS) {

			// GRASS AND MOSS MORTALITY

			if (indiv.pft.landcover==CROPLAND)
				fpc_grass=indiv.fpc;

			// Shading mortality: grasses can persist only on regions not occupied
			// by trees

			if (fpc_grass>1.0-min(fpc_tree,FPC_TREE_MAX)) {
				fpc_dec=(fpc_grass-1.0+min(fpc_tree,FPC_TREE_MAX))*indiv.fpc/fpc_grass;
				mort_shade=1.0-fracmass_lpj(indiv.fpc-fpc_dec,indiv.fpc,indiv);
			}
			else
				mort_shade=0.0;

			// Mortality due to fire

			if (patch.has_fires() && firemodel == GLOBFIRM) {
				mort_fire=fireprob*(1.0-indiv.pft.fireresist);
			}
			else {
				mort_fire=0.0;
			}

			// Sum mortality components to give total mortality (maximum 1)

			mort=min(mort_shade+mort_fire,1.0);

			// Reduce C biomass on modelled area basis to account for biomass lost
			// through mortality
			indiv.reduce_biomass(mort, mort_fire);
		}

		// Remove this PFT population completely if all individuals killed

		if (negligible(indiv.densindiv)) {
			vegetation.killobj();
			killed=true;
		}

		// Update allometry

		else allometry(indiv);

		if (!killed) vegetation.nextobj(); // ... on to next individual
	}
}


void mortality_guess(Stand& stand, Patch& patch, const Climate& climate, double fireprob, const Gridcell& gridcell) {

	// DESCRIPTION
	// Mortality in cohort and individual modes.
	// Simulates death of individuals or reduction in individual density through
	// mortality (including fire mortality) each simulation year for trees, and
	// reduction in biomass due to fire for grasses; kills individuals/cohorts if
	// climate conditions become unsuitable for survival.
	//
	// For trees, death can result from the following factors:
	//
	//   (1) a background mortality rate related to PFT mean longevity;
	//   (2) when mean growth efficiency over an integration period (five years) falls
	//       below a PFT-specific threshold;
	//   (3) stress associated with high temperatures (a "soft" bioclimatic limit,
	//       intended mainly for boreal tree PFTs; Sitch et al 2001, Eqn 55);
	//   (4) fire (probability calculated in function fire)
	//   (5) when climatic conditions are such that all individuals of the PFT are
	//       killed.
	//
	// For grasses, (4) and (5) above are modelled only.
	//
	// For trees and in cohort mode, mortality may be stochastic or deterministic
	// (according to the value of global variable ifstochmort). In stochastic mode,
	// expected mortality rates are imposed as stochastic probabilities of death; in
	// deterministic mode, cohort density is reduced by the fraction represented by
	// the mortality rate.

	// INPUT PARAMETER
	// fireprob = probability of fire in this patch

	// Overall mortality (excluding fire mortality): fraction of cohort killed, or:
	// probability of individual being killed
	double mort;
	// Background component of overall mortality (see 'mort')
	double mort_min;
	// Component of overall mortality associated with low growth efficiency
	double mort_greff;
	// Expected fraction of cohort killed (or: probability of individual being
	// killed) due to fire
	double mort_fire;
	// Fraction of cohort (or individual) surviving
	double frac_survive;
	// Growth efficiency for individual/cohort this year (kgC/m2 leaf/year)
	double greff;
	// Five-year-mean growth efficiency (kgC/m2 leaf/year)
	double greff_mean;
	// Number of individuals (remaining) in cohort
	int nindiv; 
	double nindiv_d; // TA mort_output
	// Number of individuals in cohort prior to mortality
	int nindiv_prev; 
	double nindiv_prev_d; // TA mort_output
	int i;
	bool killed;

	// Value of mort_greff when growth efficiency below PFT-specific threshold
	const double KMORTGREFF=0.3;
	// Coefficient in calculation of background mortality (negated natural log of
	// fraction of population expected to survive to age 'longevity'; see Eqn 14
	// below)
	const double KMORTBG_LNF=-log(0.001);
	// Exponent in calculation of background mortality (shape parameter for
	// relationship between mortality and age (0=constant mortality; 1=linear
	// increase; >1->exponential; steepness increases for increasing positive
	// values)
	const double KMORTBG_Q=2.0;

	/// TA: empirically based drought tree mortality
	// Component of overall mortality associated with drought mortality
	double mort_drought = 0;
	double amort_drought = 0.0;

	// TA mort_output
	nindiv_d = 0;
	nindiv_prev_d = 0;

	// TA maximum height
	double max_height = 0.0;

	// Obtain reference to Vegetation object for this patch

	Vegetation& vegetation=patch.vegetation;

	ManagementType& mt = stand.get_current_management();

	// FPC on peatlands
	double fpc_grass = 0.0;
	double fpc_moss = 0.0;
	double fpc_other = 0.0;

	if ((patch.stand.is_highlatitude_peatland_stand() || patch.stand.is_true_wetland_stand()) && wetlandlailimit > 0) {

		vegetation.firstobj();
		while (vegetation.isobj) {
			Individual& indiv = vegetation.getobj();

			// For this individual ...
			if (indiv.pft.lifeform == MOSS)
				fpc_moss += indiv.fpc;
			else if (indiv.pft.lifeform == GRASS)
				fpc_grass += indiv.fpc;
			else
				fpc_other += indiv.fpc;

			vegetation.nextobj(); // ... on to next individual
		}
	}


	// FIRE MORTALITY GLOBFIRM
	// For BLAZE there is a separate call in simulate_day (framework.cpp)
	if (patch.has_fires() && firemodel == GLOBFIRM) {

		// Impose fire in this patch with probability 'fireprob'

		if (randfrac(stand.seed)<fireprob) {

			// Loop through individuals

			vegetation.firstobj();
			while (vegetation.isobj) {
				Individual& indiv=vegetation.getobj();

				// For this individual ...

				killed=false;

				// Fraction of biomass destroyed by fire

				mort_fire=1.0-indiv.pft.fireresist;

				if (indiv.pft.lifeform==GRASS || indiv.pft.lifeform==MOSS) {

					// GRASS AND MOSS PFTs

					// Reduce individual biomass
					indiv.reduce_biomass(mort_fire, mort_fire);

					// Update allometry

					allometry(indiv);
				}
				else {

					// TREE PFT

					if (ifstochmort && mt.stochmort) {

						// Impose stochastic mortality
						// Each individual in cohort dies with probability 'mort_fire'

						// Number of individuals represented by 'indiv'
						// (round up to be on the safe side)

						nindiv=(int)(indiv.densindiv*patcharea+0.5);
						nindiv_prev=nindiv;

						for (i=0;i<nindiv_prev;i++)
							if (randfrac(stand.seed)>indiv.pft.fireresist) nindiv--;

						if (nindiv_prev)
							frac_survive=(double)nindiv/(double)nindiv_prev;
						else
							frac_survive=0.0;
					}

					// Deterministic mortality (cohort mode only)

					else frac_survive=1.0-mort_fire;

					// Reduce individual biomass on patch area basis
					// to account for loss of killed individuals
					indiv.reduce_biomass(1.0 - frac_survive, 1.0 - frac_survive);

					// Remove this cohort completely if all individuals killed
					// (in individual mode: removes individual if killed)

					if (negligible(indiv.densindiv)) {
						vegetation.killobj();
						killed=true;
					}
				}

				if (!killed) vegetation.nextobj(); // ... on to next individual
			}
		}
	}

	// MORTALITY NOT ASSOCIATED WITH FIRE

	// Calculate this year's mortality due to drought //TA
	// seasons: winter = 0, spring = 1, summer = 2, autumn = 3
	// dev_years: 0yr = 2, 1yr = 1, 2yr=0


	// model 1

/*	double intercept = -59.5755;

	mort_drought = 1 / (1 + (exp(-(intercept +
						-0.0021 * patch.dev_cwb_seasonal_summer_3[1] +
						-0.0065 * patch.dev_cwb_seasonal_summer_3[0] +
						-0.0003 * climate.insol_sum_longterm_mean_seasonal[2] +
						0.2198 * climate.mean_temp_longterm_mean_seasonal[0] +
						0.0006 * climate.dev_insol_seasonal_spring_3[1] +
						0.0006 * climate.dev_insol_seasonal_winter_3[0] +
						-0.0050 * climate.dev_prec_seasonal[0] +
						0.3524 * climate.dev_temp_seasonal_autumn_3[1] +
						0.0006 * climate.dev_insol_seasonal_summer_3[1]
						))));

	// model 2

	double intercept = -71.1567;

	mort_drought = 1 / (1 + (exp(-(intercept +
						-0.0059 * patch.dev_cwb_rollmean_3yr_seasonal[2] +
						-0.3129 * climate.dev_temp_rollmax_2yr_seasonal[2] +
						1.7909 * climate.dev_temp_rollmean_5yr_seasonal[2] +
						-0.0005 * climate.insol_sum_longterm_mean_seasonal[2] +
						0.2754 * climate.mean_temp_longterm_mean_seasonal[0]
						))));


/*	// model 3a

	double intercept = -60.5263314295;

	mort_drought = 1 / (1 + (exp(-(intercept +
						-0.0018711122 * patch.dev_cwb_seasonal_summer_3[1] +
						0.2358761165 * climate.dev_temp_rollmax_2yr_seasonal[2] +
						-0.0066415832 * patch.dev_cwb_seasonal_summer_3[0] +
						-0.0003705264 * climate.insol_sum_longterm_mean_seasonal[2] +
						0.2270523993 * climate.mean_temp_longterm_mean_seasonal[0] +
						0.0005133246 * climate.dev_insol_seasonal_spring_3[1] +
						0.0007165456 * climate.dev_insol_seasonal_winter_3[0] +
						-0.0049022267 * climate.dev_prec_seasonal[0] +
						0.3218247520 * climate.dev_temp_seasonal_autumn_3[1] +
						0.0004576259 * climate.dev_insol_seasonal_summer_3[1]
						))));
*/


/*	// model 3b

	double intercept = -67.762949;

	mort_drought = 1 / (1 + (exp(-(intercept +
						-0.0017092 * patch.dev_cwb_seasonal_summer_3[1] +
						0.8069031 *climate.dev_temp_rollmean_5yr_seasonal[2] +
						-0.0052448 * patch.dev_cwb_seasonal_summer_3[0] +
						-0.0003761 * climate.insol_sum_longterm_mean_seasonal[2] +
						0.2531132 * climate.mean_temp_longterm_mean_seasonal[0] +
						0.0003958 * climate.dev_insol_seasonal_spring_3[1] +
						0.0002416 * climate.dev_insol_seasonal_winter_3[0] +
						-0.0048414 * climate.dev_prec_seasonal[0] +
						0.1421319 * climate.dev_temp_seasonal_autumn_3[1] +
						0.0004072 * climate.dev_insol_seasonal_summer_3[1]
						))));
*/

			/*if (date.get_calendar_year() >= 1998 & date.get_calendar_year () <= 2021 & stand.id == 1){
							dprintf("Year  = %i\n", date.get_calendar_year());
							dprintf("mort_drought = %f\n", mort_drought);
							/*dprintf("cwb_summer_dev_1yr  = %f\n", patch.dev_cwb_seasonal_summer_3[1]);
							dprintf("cwb_summer_dev_2yr  = %f\n", patch.dev_cwb_seasonal_summer_3[0]);
							dprintf("rsds_long_mean_1980_2009_summer = %f\n", climate.insol_sum_longterm_mean_seasonal[2]);
							dprintf("temp_long_mean_1980_2009_winter  = %f\n", climate.mean_temp_longterm_mean_seasonal[0]);
							dprintf("rsds_spring_dev_1yr  = %f\n", climate.dev_insol_seasonal_spring_3[1]);
							dprintf("rsds_winter_dev_2yr  = %f\n", climate.dev_insol_seasonal_winter_3[0]);
							dprintf("prec_winter_dev_0yr  = %f\n", climate.dev_prec_seasonal[0]);
							//dprintf("temp_mean_autumn_dev_1yrs  = %f\n", climate.dev_temp_seasonal_autumn_3[1]);
							dprintf("rsds_summer_dev_1yr  = %f\n", climate.dev_insol_seasonal_summer_3[1]);
							//dprintf("cwb_summer_3yr_rollmean_dev = %f\n", patch.dev_cwb_rollmean_3yr_seasonal[2]);
							//dprintf("temp_summer_5yr_rollmean_dev = %f\n", climate.dev_temp_rollmean_5yr_seasonal[2]);
							dprintf("temp_summer_2yr_rollmax_dev = %f\n", climate.dev_temp_rollmax_2yr_seasonal[2]);

						}*/

	// Working drought mortality 21.12.2023
/*	double intercept = -60.0381991004052;

		mort_drought = 1 / (1 + (exp(-(intercept +
							-0.00186278081755916 * patch.dev_cwb_seasonal_summer_3[1] +
							-0.00620289170831088 * patch.dev_cwb_seasonal_summer_3[0] +
							//0.00171294792201826 * patch.dev_cwb_min_seasonal[2] +
							-0.000341506705034922* climate.insol_sum_longterm_mean_seasonal[2] +
							0.223516571768093 * climate.mean_temp_longterm_mean_seasonal[0] +
							0.00057199582698491 * climate.dev_insol_seasonal_spring_3[1] +
							//0.00126805622100995 * patch.dev_cwb_seasonal_winter_3[0] +
							0.000631014344396749 * climate.dev_insol_seasonal_winter_3[0] +
							-0.00484498203027498 * climate.dev_prec_seasonal[0] +
							0.342201728307404 * climate.dev_temp_seasonal_autumn_3[1] +
							0.000618736097446636 * climate.dev_insol_seasonal_summer_3[1]
							))));
*/

/*					if (date.get_calendar_year() >= 2018 & date.get_calendar_year() <= 2020){
						dprintf("Year = %i\n", date.get_calendar_year());
						dprintf("Drought mortality = %f\n", mort_drought);
					}
*/


	// Drought mortality based on standing deadwood satellite data
/*if (date.get_calendar_year() >= 1980){
	double intercept = -54.9366;

	mort_drought = exp(intercept +
						-0.0470 * gridcell.spruce_can_height[2] +
						-0.0027 * patch.dev_cwb_rollmean_2yr_GS +
						0.3357 * climate.dev_max_temp_seasonal_summer_3[1] +
						0.2472 * (climate.temp_mean_seasonal[0] + 273.15) +
						0.0522 * climate.late_frost_days +
						-0.0600 * climate.mean_temp_longterm_mean_seasonal[0]);
}
	if (date.get_calendar_year() >= 2018 & date.get_calendar_year() <= 2020){
		dprintf("Year = %i\n", date.get_calendar_year());
		dprintf("Spruce canopy height = %f\n", gridcell.spruce_can_height[2]);
		dprintf("CWB anom summer rollmean = %f\n", patch.dev_cwb_rollmean_2yr_GS);
		dprintf("Max. temp summer anomaly 1yr prior = %f\n", climate.dev_max_temp_seasonal_summer_3[1]);
		dprintf("Winter mean temp = %f\n", climate.temp_mean_seasonal[0]);
		dprintf("Late frost days = %i\n", climate.late_frost_days);
		dprintf("Longterm mean temp winter = %f\n", climate.mean_temp_longterm_mean_seasonal[0]);
		dprintf("Drought mortality = %f\n", mort_drought);
	}
*/
	// Drought mortality based on standing deadwood satellite data (canopy height of 2 years prior)
/*	if (date.get_calendar_year() >= 1980){
		double intercept = -60.1242;


	mort_drought = exp(intercept +
						-0.04759 * gridcell.spruce_can_height[1] +
						-0.002352 * patch.dev_cwb_rollmean_2yr_GS +
						0.355343 * climate.dev_max_temp_seasonal_summer_3[1] +
						0.258306 * (climate.temp_mean_seasonal[0] + 273.15) +
						0.056791 * climate.late_frost_days +
						-0.055934 * climate.mean_temp_longterm_mean_seasonal[0]);
	}

	if (date.get_calendar_year() >= 2018 & date.get_calendar_year() <= 2020){
		dprintf("Year = %i\n", date.get_calendar_year());
		dprintf("Spruce canopy height = %f\n", gridcell.spruce_can_height[1]);
		dprintf("CWB anom summer rollmean = %f\n", patch.dev_cwb_rollmean_2yr_GS);
		dprintf("Max. temp summer anomaly 1yr prior = %f\n", climate.dev_max_temp_seasonal_summer_3[1]);
		dprintf("Winter mean temp = %f\n", climate.temp_mean_seasonal[0]);
		dprintf("Late frost days = %i\n", climate.late_frost_days);
		dprintf("Longterm mean temp winter = %f\n", climate.mean_temp_longterm_mean_seasonal[0]);
		dprintf("Drought mortality = %f\n", mort_drought);
	}*/

	// Drought mortality based on standing deadwood satellite data
		if (date.get_calendar_year() >= 2010){
			double intercept = -4.44692;
			double log_mort_drought = 0.0;

			log_mort_drought = intercept +
					-0.00057 * patch.min_cwb_seasonal_summer +
					 0.00068 * climate.insol_anom_summer_roll_mean_2yrs +
					 0.00027 * climate.dev_insol_seasonal[1] +
					 0.04956 * climate.min_temp_mean_seasonal[0] +
					 0.09194 * climate.dev_max_temp_seasonal_summer_3[1] +
					 0.02022 * climate.late_frost_days;

			mort_drought = exp(log_mort_drought);


			// Handling extremes
			//mort_drought = min(mort_drought, 1.0);
			//if(mort_drought < 0){
			//	mort_drought = 0;
			//}
		}

		/*if (date.get_calendar_year() == 2020){
			dprintf("Year = %i\n", date.get_calendar_year());
			dprintf("cwb_JJA_roll_min_5yrs = %f\n", patch.min_cwb_seasonal_summer);
			dprintf("rsds anom JJA roll mean 2yrs = %f\n", climate.insol_anom_summer_roll_mean_2yrs);
			dprintf("rsds anom MAM = %f\n", climate.dev_insol_seasonal[1]);
			dprintf("Winter min temp = %f\n", climate.min_temp_mean_seasonal[0]);
			dprintf("Max. temp summer anomaly 1yr prior = %f\n", climate.dev_max_temp_seasonal_summer_3[1]);
			dprintf("Late frost days = %i\n", climate.late_frost_days);
			dprintf("log drought mortality = %f\n", log_mort_drought);
			dprintf("Drought mortality = %f\n", mort_drought);
		}*/
	// Loop through individuals

	vegetation.firstobj();
	while (vegetation.isobj) {
		Individual& indiv=vegetation.getobj();
		Patchpft& patchpft = patch.pft[indiv.pft.id];

		// For this individual ...

		killed=false;

		// KILL INDIVIDUALS/COHORTS BEYOND BIOCLIMATIC LIMITS FOR SURVIVAL

		if (!survive(climate,indiv.pft)) {

			// Kill cohort/individual, transfer biomass to litter

			patchpft.cmass_mort += indiv.ccont();
			patchpft.cmass_mort_wood += indiv.cmass_wood();
			if (indiv.diam >= 0.1)
				patchpft.cmass_mort_wood_plus10cm += indiv.cmass_wood();

			indiv.kill();

			vegetation.killobj();
			killed=true;
		}
		else {

			if (indiv.pft.lifeform==TREE) {

				// Calculate this year's growth efficiency
				// Eqn 31, Smith et al 2001

				if (!negligible(indiv.cmass_leaf))
					greff=max(indiv.anpp,0.0)/indiv.cmass_leaf/indiv.pft.sla;
				else
					greff=0.0;

				// Calculate 5 year mean growth efficiency

				indiv.greff_5.add(greff);
				greff_mean = indiv.greff_5.mean();

				// BACKGROUND MORTALITY
				//
				// This is now modelled as an increasing probability of death with
				// age. The expected likelihood of death by "background" factors at a
				// given age is given by the general relationship [** = raised to the
				// power of]:
				//  (1) mort(age) = min( Z * ( age / longevity ) ** Q , 1)
				// where Z         is a constant (value derived below);
				//       Q         is a positive constant
				//                 (or zero for constant mortality with age)
				//       longevity is the age at which the fraction of the initial
				//                 cohort expected to survive is a known value, F
                // It is possible to derive the value of Z given values for longevity,
				// Q and F, by integration:
				//
				// The rate of change of cohort size (P) at any age is given by:
				//  (2) dP/dage = -mort(age) * P
				// Combining (1) and (2),
				//  (3) dP/dage = -Z.(age/longevity)**Q.P
				// From (3),
				//  (4) (1/P) dP = -Z.(age/longevity)**Q.dage
				// Integrating the LHS of eqn 4 from P_0 (initial cohort size) to
				// P_longevity (cohort size at age=longevity); and the RHS of eqn 4
				// from 0 to longevity:
				//   (5) LHS = ln(P_longevity) - ln(P_0)
				//   (6)     = ln(P_longevity/P_0)
				//   (7)     = ln(P_0*F/P_0)
				//   (8)     = ln(F)
				//   (9) RHS = integral[0,longevity] -Z.(age/longevity)**Q.dage
				//  (10)     = integral[0,longevity] -Z.(1/longevity)**Q.age**Q.dage
				//  (11)     = -Z.(1/longevity)**Q.integral[0,longevity] age**Q.dage
				//  (12)     = -Z.(1/longevity)**Q.longevity**(Q+1)/(Q+1)
				//             (Zwillinger 1996, p 360)
				// Combining (8) and (12),
				//  (13) Z = - ln(F) * (Q+1) / longevity
				// Combining (1) and (13),
				//  (14) mort(age) =
				//         min ( -ln(F) * (Q+1) / longevity * (age/longevity)**P, 1)

				// Eqn 14
				mort_min=min(1.0,KMORTBG_LNF*(KMORTBG_Q+1)/indiv.pft.longevity*
					pow(indiv.age/indiv.pft.longevity,KMORTBG_Q));


				// Growth suppression mortality
				// Smith et al 2001; c.f. Pacala et al 1993, Eqn 5

				// guess2008 - introduce a smoothly-varying mort_greff - 5 is the exponent in the global validation
				if (ifsmoothgreffmort)
					mort_greff=KMORTGREFF/(1.0+pow((greff_mean/(indiv.pft.greff_min)),5.0));
				else {
					// Standard case, as in guess030124
					if (greff_mean<indiv.pft.greff_min)
						mort_greff=KMORTGREFF;
					else
						mort_greff=0.0;
				}


				// Increase growth efficiency mortality if summed crown area within
				// cohort exceeds 1 (to ensure self-thinning for shade-tolerant PFTs)

				if (vegmode==COHORT) {

					if (indiv.crownarea*indiv.densindiv>1.0)
						mort_greff=max((indiv.crownarea*indiv.densindiv-1.0)/
							(indiv.crownarea*indiv.densindiv),mort_greff);
				}

				patch.amort_drought = 0.0;

				if (indiv.pft.name == "Pic_abi") {
					patch.amort_drought = mort_drought;
				}
				//dprintf("PFT = %i\n", indiv.pft.id);
				/*if (date.get_calendar_year() == 1857 & indiv.pft.name == "Pic_abi"){
					dprintf("Year = %d\n", date.get_calendar_year());
					dprintf("PFT mort drought = %f\n", patch.amort_drought);
				}*/

				// Overall mortality: c.f. Eqn 29, Smith et al 2001
				mort = mort_min + mort_greff - mort_min*mort_greff;
				
				if (date.get_calendar_year () >= 2010) {
				    mort= mort_min + mort_greff + patch.amort_drought - mort_min * mort_greff - mort_min * patch.amort_drought - mort_greff * patch.amort_drought + mort_min * mort_greff * patch.amort_drought;
				    mort = min(mort, 1.0);
				 }

				/*if (date.get_calendar_year() >= 1980){
					mort = (mort_min+mort_greff-mort_min*mort_greff) + patch.amort_drought;
					mort = min(mort, 1.0);
	   

				// Save number of individuals before mortality //TA
				nindiv_d = indiv.densindiv;
				nindiv_prev_d = nindiv_d;



				// Overall mortality, calculated as default lpj-guess mortality //TA
				indiv.amort_def = 0.0;
				indiv.amort_def = mort_min + mort_greff - mort_min * mort_greff;
				indiv.amort_def = min(indiv.amort_def, 1.0);

				//dprintf("Overall mortality = %f\n", mort);
				indiv.amort_greff = 0.0;
				indiv.amort_greff = mort_greff;
				indiv.amort_min = mort_min;
				indiv.amort = 0.0;
				indiv.amort = mort;

				/*if (date.get_calendar_year() == 2020 & indiv.pft.name == "Pic_abi"){
					dprintf("mort_def = %f\n", indiv.amort_def);
					dprintf("mort_min = %f\n", mort_min);
					dprintf("mort_greff = %f\n", mort_greff);
					//dprintf("mort_min + mort_greff = %f\n", mort_min+mort_greff);
					//dprintf("mort_min * mort_greff = %f\n", mort_min*mort_greff);
					dprintf("mort_drought = %f\n", patch.amort_drought);
					dprintf("mort = %f\n", mort);
				}*/
				// guess2008 - added safety check
				if (mort > 1.0 || mort < 0.0)
					fail("error in mortality_guess: bad mort value");

				if (ifstochmort && mt.stochmort) {

					// Impose stochastic mortality
					// Each individual in cohort dies with probability 'mort'

					nindiv=(int)(indiv.densindiv*patcharea+0.5);
					nindiv_prev=nindiv;

					for (i=0;i<nindiv_prev;i++)
						if (randfrac(stand.seed)<mort) nindiv--;

					if (nindiv_prev)
						frac_survive=(double)nindiv/(double)nindiv_prev;
					else
						frac_survive=0.0;
				}

				// Deterministic mortality (cohort mode only)

				else frac_survive=1.0-mort;

				patchpft.cmass_mort += (1.0 - frac_survive) * indiv.ccont();
				patchpft.cmass_mort_wood += (1.0 - frac_survive) * indiv.cmass_wood();
				if (indiv.diam >= 0.1)
					patchpft.cmass_mort_wood_plus10cm += (1.0 - frac_survive) * indiv.cmass_wood();

				// Reduce individual density and biomass on patch area basis
				// to account for loss of killed individuals
				indiv.reduce_biomass(1.0 - frac_survive, 0.0);

				indiv.densindiv_dead = (nindiv_prev_d - indiv.densindiv) * M2_PER_HA;

				/*if ((date.get_calendar_year() == 2010 & indiv.pft.name == "Pic_abi") || (date.get_calendar_year() == 2019 & indiv.pft.name == "Pic_abi")){
					dprintf("Year = %d\n", date.get_calendar_year());
					dprintf("Age = %f\n", indiv.age);
					dprintf("nindiv_prev = %f\n", nindiv_prev_d* M2_PER_HA);
					dprintf("nindiv = %f\n", indiv.densindiv* M2_PER_HA);
					dprintf("densindiv_dead = %f\n", indiv.densindiv_dead);
					dprintf("mort_calc = %f\n", indiv.densindiv_dead / (nindiv_prev_d * M2_PER_HA)*100);
					dprintf("mort = %f\n", mort*100);
				}*/

				// Remove this cohort completely if all individuals killed
				// (in individual mode: removes individual if killed)

				if (negligible(indiv.densindiv)) {
					vegetation.killobj();
					killed=true;
				}

				// Update allometry

				else allometry(indiv);
			} 
			else { 
				
				// MORTALITY in PEATLAND stands
				// i.e. shading mortality when LAI gets too high (cf mortality_lpj above), whereupon
				// biomass is reduced (ends up in litter) to be consistent with the given LAI limit (maxlai_peatland)
				if ((patch.stand.is_highlatitude_peatland_stand() || patch.stand.is_true_wetland_stand()) && wetlandlailimit > 0.0) {

					double mort_shade = 0.0;

					double fpc_peat = fpc_moss + fpc_grass + fpc_other;

					if (!negligible(indiv.cmass_leaf)) {

						// Max values
						double maxlai_peatland = wetlandlailimit; // set from .ins file
						
						if (patch.stand.is_true_wetland_stand())
							maxlai_peatland *= 2; // Allow higher LAI values for wetlands south of PEATLAND_WETLAND_LATITUDE_LIMIT N as these are more productive  

						double maxfpc_peatland = 1.0 - exp(-0.5 * maxlai_peatland);

						// This individual

						if (indiv.fpc > maxfpc_peatland) {
							// fracmass_lpj calculates and returns new biomass as a fraction of old biomass given an FPC
							// reduction from fpc_high to fpc_low, assuming LPJ allometry
							double fpc_dec = (indiv.fpc - maxfpc_peatland) * indiv.fpc / fpc_peat;
							mort_shade = 1.0 - fracmass_lpj(indiv.fpc - fpc_dec, indiv.fpc, indiv);
						}

						// Reduce C biomass to account for biomass lost through shading mortality
						if (mort_shade> 0.0) {
							patchpft.cmass_mort += mort_shade * indiv.ccont();
							patchpft.cmass_mort_wood += mort_shade * indiv.cmass_wood();
							if (indiv.diam >= 0.1)
								patchpft.cmass_mort_wood_plus10cm += mort_shade * indiv.cmass_wood();
							indiv.reduce_biomass(mort_shade, 0.0);
							allometry(indiv);
						}

					} // correct stand and grass type

				} // limit lai only
			}
		}

		// ... on to next individual

		if (!killed) vegetation.nextobj();
	}
}


///////////////////////////////////////////////////////////////////////////////////////
// FIRE DISTURBANCE
// Internal function (do not call directly from framework)

void fire(Patch& patch,double& fireprob) {

	// DESCRIPTION
	// Calculates probability/incidence of disturbance by fire; implements
	// volatilisation of above-ground litter due to fire.
	// Mortality due to fire implemented in mortality functions, not here.
	//
	// Reference: Thonicke et al 2001, with updated Eqn 9

	// OUTPUT PARAMETER
	// fireprob = probability of fire in this patch this year
	//            (in population mode: fraction of modelled area affected by fire)

	// Minimum total aboveground litter required for fire (kgC/m2)
	const double MINFUEL=0.2;
	// Total aboveground litter (kgC/m2) [litter_ag_total/1000, fuel/1000; LPJF]
	double litter_ag;
	// Mean litter flammability moisture threshold [=moisture of extinction, me;
	// Thonicke et al 2001 Eqn 2; moistfactor; LPJF]
	double me_mean;
	// Probability of fire on a given day [p(m); Thonicke et al 2001, Eqn 2;
	// fire_prob; LPJF]
	double pm;
	// Summed length of fire season (days) [N; Thonicke et al 2001, Eqn 4;
	// fire_length; LPJF]
	double n;
	// Annual mean daily probability of fire [s; Thonicke et al 2001, Eqn 8;
	// fire_index; LPJF]
	double s;
	
	double sm; // s-1
	double mort_fire; // fire mortality as fraction of current FPC
	int p;

	// Calculate fuel load (total aboveground litter)

	litter_ag=0.0;

	// Loop through PFTs

	for (p=0;p<npft;p++) {
		litter_ag += patch.pft[p].cmass_litter_leaf + patch.pft[p].cmass_litter_sap + patch.pft[p].cmass_litter_heart +
			patch.pft[p].cmass_litter_repr;
	}

	// Soil Litter
	litter_ag += patch.soil.sompool[SURFSTRUCT].cmass + patch.soil.sompool[SURFMETA].cmass +
		patch.soil.sompool[SURFFWD].cmass + patch.soil.sompool[SURFCWD].cmass;

	// Prevent fire if fuel load below prescribed threshold

	if (litter_ag<MINFUEL) {
		fireprob=0.0;
		return;
	}

	// Calculate mean litter flammability moisture threshold

	me_mean=0.0;

	// Loop through PFTs

	for (p=0;p<npft;p++) {
		me_mean += (patch.pft[p].cmass_litter_leaf + patch.pft[p].cmass_litter_sap + patch.pft[p].cmass_litter_heart +
			patch.pft[p].cmass_litter_repr) * patch.pft[p].pft.litterme / litter_ag;
	}

	// Soil litter
	me_mean += (patch.soil.sompool[SURFSTRUCT].cmass * patch.soil.sompool[SURFSTRUCT].litterme +
		patch.soil.sompool[SURFMETA].cmass * patch.soil.sompool[SURFMETA].litterme +
		patch.soil.sompool[SURFFWD].cmass * patch.soil.sompool[SURFFWD].litterme +
		patch.soil.sompool[SURFCWD].cmass * patch.soil.sompool[SURFCWD].litterme) / litter_ag;

	// Calculate length of fire season in days
	// Eqn 2, 4, Thonicke et al 2001
	// NOTE: error in Eqn 2, Thonicke et al - multiplier should be PI/4, not PI

	n=0.0;
	for (int day = 0; day < date.year_length(); day++) {

		// No fires unless there is some soil melt.
		if (iftwolayersoil || (patch.soil.dthaw[day] > 0.0 && date.year > FIRST_FREEZE_YEAR + 10)) {
			pm = exp(-PI*patch.soil.dwcontupper[day] / me_mean*patch.soil.dwcontupper[day] /
				me_mean);		// Eqn 2
		}
		else {
			pm = 0.0;
		}
			

		// Eqn 4
		n+=pm;
	}

	// Calculate fraction of grid cell burnt
	// Thonicke et al 2001, Eqn 9

	s=n/(double)date.year_length();
	sm=s-1;

	fireprob=s*exp(sm/(0.45*sm*sm*sm+2.83*sm*sm+2.96*sm+1.04));

	if (fireprob>1.0)
		fail("fire: probability of fire >1.0");
	else if (fireprob<0.001) fireprob=0.001; // c.f. LPJF

	// Calculate expected flux from litter due to fire
	// (fluxes from vegetation calculated in mortality functions)

	for (p=0;p<npft;p++) {

		// Assume litter is as fire resistant as the vegetation it originates from

		mort_fire=fireprob*(1.0-patch.pft[p].pft.fireresist);

		// Calculate flux from burnt litter

		patch.fluxes.report_flux(Fluxes::FIREC,
		                         mort_fire*(patch.pft[p].cmass_litter_leaf + patch.pft[p].cmass_litter_sap +
		                                    patch.pft[p].cmass_litter_heart + patch.pft[p].cmass_litter_repr));

		report_fire_nfluxes(patch, mort_fire * (patch.pft[p].nmass_litter_leaf +
			                patch.pft[p].nmass_litter_sap + patch.pft[p].nmass_litter_heart));

		// Account for burnt above ground litter

		patch.pft[p].cmass_litter_leaf  *= (1.0 - mort_fire);
		patch.pft[p].cmass_litter_sap   *= (1.0 - mort_fire);
		patch.pft[p].cmass_litter_heart *= (1.0 - mort_fire);
		patch.pft[p].cmass_litter_repr  *= (1.0 - mort_fire);
		patch.pft[p].nmass_litter_leaf  *= (1.0 - mort_fire);
		patch.pft[p].nmass_litter_sap   *= (1.0 - mort_fire);
		patch.pft[p].nmass_litter_heart *= (1.0 - mort_fire);
	}

	// Soil litter
	double mort_fire_struct = fireprob * (1.0 - patch.soil.sompool[SURFSTRUCT].fireresist);
	double mort_fire_meta   = fireprob * (1.0 - patch.soil.sompool[SURFMETA].fireresist);
	double mort_fire_fwd    = fireprob * (1.0 - patch.soil.sompool[SURFFWD].fireresist);
	double mort_fire_cwd    = fireprob * (1.0 - patch.soil.sompool[SURFCWD].fireresist);

	// Calculate flux from burnt soil litter
	patch.fluxes.report_flux(Fluxes::FIREC,patch.soil.sompool[SURFSTRUCT].cmass * mort_fire_struct +
	                                       patch.soil.sompool[SURFMETA].cmass   * mort_fire_meta +
	                                       patch.soil.sompool[SURFFWD].cmass    * mort_fire_fwd +
	                                       patch.soil.sompool[SURFCWD].cmass    * mort_fire_cwd);

	// Account for burnt above ground litter
	patch.soil.sompool[SURFSTRUCT].cmass *= (1.0 - mort_fire_struct);
	patch.soil.sompool[SURFMETA].cmass   *= (1.0 - mort_fire_meta);
	patch.soil.sompool[SURFFWD].cmass    *= (1.0 - mort_fire_fwd);
	patch.soil.sompool[SURFCWD].cmass    *= (1.0 - mort_fire_cwd);

	// Calculate nitrogen flux from burnt soil litter
	double nflux_fire = patch.soil.sompool[SURFSTRUCT].nmass * mort_fire_struct +
	                    patch.soil.sompool[SURFMETA].nmass   * mort_fire_meta +
	                    patch.soil.sompool[SURFFWD].nmass    * mort_fire_fwd +
						patch.soil.sompool[SURFCWD].nmass    * mort_fire_cwd;

	report_fire_nfluxes(patch, nflux_fire);

	patch.soil.sompool[SURFSTRUCT].nmass *= (1.0 - mort_fire_struct);
	patch.soil.sompool[SURFMETA].nmass   *= (1.0 - mort_fire_meta);
	patch.soil.sompool[SURFFWD].nmass    *= (1.0 - mort_fire_fwd);
	patch.soil.sompool[SURFCWD].nmass    *= (1.0 - mort_fire_cwd);
}


///////////////////////////////////////////////////////////////////////////////////////
// DISTURBANCE
// Generic patch-destroying disturbance with a prescribed probability
// Internal function - do not call from framework

void disturbance(Patch& patch, double disturb_prob) {

	// DESCRIPTION
	// Destroys all biomass in a patch with a certain stochastic probability.
	// Biomass enters the litter, which is not affected by the disturbance.
	// NB: cohort and individual mode only

	// INPUT PARAMETER
	// disturb_prob = the probability of a disturbance this year

	if (randfrac(patch.stand.seed)<disturb_prob) {

		Vegetation& vegetation = patch.vegetation;

		vegetation.firstobj();
		while (vegetation.isobj) {
			Individual& indiv = vegetation.getobj();
			Patchpft& patchpft = patch.pft[indiv.pft.id];

			if(indiv.alive)
				patchpft.cmass_dist += indiv.ccont();

			indiv.kill();

			vegetation.killobj();
		}

		patch.disturbed = true;
		patch.age_print = patch.age + 1;
		patch.age = 0;
	}

	else patch.disturbed = false;
}

/// PLANTING
// Planting of trees in managed forest

void planting(Patch& patch) {

	double ltor;
	Stand& stand = patch.stand;

	pftlist.firstobj();
	while (pftlist.isobj) {
		Pft& pft = pftlist.getobj();

		Standpft& spft = patch.stand.pft[pft.id];
		bool pft_selection = spft.plant;

		if(pft_selection) {

			Standpft& spft = stand.pft[pft.id];
			// plants per ha., could be modified by stand productivity
			double plantdensity = 1000;	// temporary default value if not specified for pft
			if(spft.plantdensity >= 0.0) {
				plantdensity = spft.plantdensity;
			}
			else if(pft.plantdensity) {
				plantdensity = pft.plantdensity;
			}

			if(plantdensity) {
				Individual& indiv = patch.vegetation.createobj(pft, patch.vegetation);
				indiv.densindiv = plantdensity / 10000.0;	// per ha to per m2
				ltor = pft.ltor_max;

				if (ifnewalloc) {
					allocation_init(PLANTSIZE, ltor, indiv, 0.0);
				}
				else {
					allocation_init(PLANTSIZE, ltor, indiv);
				}

				allometry(indiv);

				// Calculate storage pool size
				indiv.max_n_storage = indiv.cmass_sap * indiv.pft.fnstorage / indiv.pft.cton_leaf_avr;
				indiv.scale_n_storage = indiv.max_n_storage * indiv.pft.cton_leaf_avr / PLANTSIZE;
			}
		}

		patch.pft[pft.id].nsapling=0.0;
		patch.pft[pft.id].wscal_mean_est=0.0;
		patch.pft[pft.id].anetps_ff_est=0.0;

		pftlist.nextobj();
	}
}

///////////////////////////////////////////////////////////////////////////////////////
// VEGETATION DYNAMICS
// Should be called by framework at the end of each simulation year, after vegetation,
// climate and soil attributes have been updated

void vegetation_dynamics(Stand& stand,Patch& patch) {

	// DESCRIPTION
	// Implementation of fire disturbance and population dynamics (establishment and
	// mortality) at end of simulation year. Bioclimatic constraints to survival and
	// establishment are imposed within mortality and establishment functions
	// respectively.

	double fireprob = 0.0;
		// probability of fire in this patch this year
		// (in population mode: fraction of modelled area affected by fire this year)

	// Calculate fire probability and volatilise litter
	if (patch.has_fires() && firemodel == GLOBFIRM) {
		fire(patch,fireprob);
	}
	patch.fireprob = fireprob;

	if (vegmode == POPULATION) {

		// POPULATION MODE

		// Mortality
		mortality_lpj(stand, patch, stand.get_climate(), fireprob);

		// Establishment
		establishment_lpj(stand,patch);

	}
	else {

		// INDIVIDUAL AND COHORT MODES

		// Patch-destroying disturbance

		// Disturbance when N limitation is switched on to get right pft composition under N limitation faster
		if (ifcentury && ifnlim && date.year == freenyears){
			disturbance(patch, 1.0);
			if (patch.disturbed) {
				return; // no mortality or establishment this year
			}
		}

		// Normal disturbance with probability interval of distinterval
		if (patch.has_disturbances()) {

			// We don't allow disturbance while documenting for calculation of Century equilibrium
			bool during_century_solvesom = ifcentury &&
										   date.year >= patch.soil.solvesomcent_beginyr &&
										   date.year <= patch.soil.solvesomcent_endyr;

			double distinterval_ = stand.get_distinterval();	
			if (patch.age && !during_century_solvesom) {
				disturbance(patch,1.0 / distinterval_);
				if (patch.disturbed) {
					return; // no mortality or establishment this year
				}
			}
		}

		// Mortality
		mortality_guess(stand, patch, stand.get_climate(), fireprob, stand.get_gridcell());

		// Establishment
		establishment_guess(stand,patch);
	}

	patch.age++;
	patch.age_print = patch.age;

	/*for (unsigned int i=0; i<patch.vegetation.nobj; i++) {

		Individual& indiv = patch.vegetation[i];
		if(indiv.pft.lifeform == TREE) {
			indiv.cmass_wood_inc_5.add(indiv.cmass_wood() - indiv.cmass_wood_old);
			indiv.cmass_wood_old = indiv.cmass_wood();
		}
	}
	*/
}


///////////////////////////////////////////////////////////////////////////////////////
// REFERENCES
//
// LPJF refers to the original FORTRAN implementation of LPJ as described by Sitch
//   et al 2001
// Fulton, MR 1991 Adult recruitment rate as a function of juvenile growth in size-
//   structured plant populations. Oikos 61: 102-105.
// Pacala SW, Canham, CD & Silander JA Jr 1993 Forest models defined by field
//   measurements: I. The design of a northeastern forest simulator. Canadian Journal
//   of Forest Research 23: 1980-1988.
// Prentice, IC, Sykes, MT & Cramer W 1993 A simulation model for the transient
//   effects of climate change on forest landscapes. Ecological Modelling 65:
//   51-70.
// Sitch, S, Prentice IC, Smith, B & Other LPJ Consortium Members (2000) LPJ - a
//   coupled model of vegetation dynamics and the terrestrial carbon cycle. In:
//   Sitch, S. The Role of Vegetation Dynamics in the Control of Atmospheric CO2
//   Content, PhD Thesis, Lund University, Lund, Sweden.
// Smith, B, Prentice, IC & Sykes, M (2001) Representation of vegetation dynamics in
//   the modelling of terrestrial ecosystems: comparing two contrasting approaches
//   within European climate space. Global Ecology and Biogeography 10: 621-637
// Thonicke, K, Venevsky, S, Sitch, S & Cramer, W (2001) The role of fire disturbance
//   for global vegetation dynamics: coupling fire into a Dynamic Global Vegetation
//   Model. Global Ecology and Biogeography 10: 661-677.
// Wolf, A., Callaghan T.V., & Larson K. (2008) Future changes in vegetation and ecosystem 
//   function of the Barents Region. Climatic Change, 87:51-73 DOI 10.1007/s10584-007-9342-
// Zwillinger, D 1996 CRC Standard Mathematical Tables and Formulae, 30th ed. CRC
//   Press, Boca Raton, Florida.
